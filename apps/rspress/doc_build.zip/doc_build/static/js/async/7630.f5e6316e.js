"use strict";(self.webpackChunkrspress_blog=self.webpackChunkrspress_blog||[]).push([["7630"],{90203:function(e,t,r){r.r(t),r.d(t,{default:()=>l});var s=r(31549),o=r(82190),a=r(44194),i=r(62377),n=r(80438);let l=()=>{let e=(0,i.e7)(),t=o.ZP.div`height:500px`,r=o.ZP.div`height:150px;position:relative`,l=o.ZP.div`
  height:150px;
  position:absolute;
  left:50%;
  transform:translateX(-50%);
  width:150px;
  border-radius:100%;
  box-shadow:0px 0px 8px rgba(0,0,0,0.5);
  z-index:1;
  `,d=o.ZP.div`
        position: absolute;
        width: 150px;
        height: 150px;
        border-radius: 100%;

  `,f=(0,o.ZP)(d)`
  transition: all 1s;
  clip: rect(0px, 75px, 150px, 0px);
 transform: rotate(30deg);
  `,x=(0,o.ZP)(d)`
  clip: rect(0px, 150px, 150px, 75px);

  `,c=o.ZP.div` position: absolute;
    width: 120px;
    height: 120px;
     background-color:${e?"#191d24":"#fff"};
    border-radius: 100%;
    top: 15px;
    left: 15px;
    box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.5) inset;
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index:2;

    `,p=o.ZP.div`
     width: 300px;
        height: 300px;
  background: conic-gradient(#179067, #62e317, #d7f10f, #ffc403, #fcc202, #ff7327, #ff7327, #FF5800, #ff5900, #f64302, #ff0000, #ff0000);
     border-radius: 50%;
        position: relative;
           
  `,h=o.ZP.div`
     position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        z-index: 2;
        width: 260px;
        height: 260px;
        background-color:${e?"#191d24":"#fff"};
        border-radius: 50%;
  `,u=(0,a.useRef)(null),[g,b]=(0,a.useState)({len:0,percent:0});return(0,a.useEffect)(()=>{if(u.current)b({len:2*u.current.r.baseVal.value*Math.PI,percent:Math.round(100*Math.random())/100})},[]),(0,s.jsxs)(t,{className:"flex flex-col justify-between items-center",children:[(0,s.jsx)(r,{children:(0,s.jsxs)(l,{children:[(0,s.jsx)(c,{}),(0,s.jsx)(x,{style:{transform:"rotate(0deg)"},children:(0,s.jsx)(f,{style:{backgroundColor:"#3498db",transform:"rotate(120deg)"}})}),(0,s.jsx)(x,{style:{transform:"rotate(120deg)"},children:(0,s.jsx)(f,{style:{backgroundColor:"#2ecc71",transform:"rotate(120deg)"}})}),(0,s.jsx)(x,{style:{transform:"rotate(240deg)"},children:(0,s.jsx)(f,{style:{backgroundColor:"#e74c3c",transform:"rotate(120deg)"}})})]})}),(0,s.jsx)(n.Z,{min:0,max:1,style:{width:"200px"},defaultValue:g.percent,onChangeComplete:e=>b({...g,percent:e}),step:.01}),(0,s.jsxs)(p,{children:[(0,s.jsx)("svg",{style:{transform:"rotate(-90deg)"},width:"300",height:"300",children:(0,s.jsx)("circle",{r:"140",ref:u,cx:"150",cy:"150",className:"stroke-[#f2f2f2] ","stroke-width":"21",fill:"transparent",style:{strokeDashoffset:-g.len*g.percent,strokeDasharray:880}})}),(0,s.jsx)(h,{})]})]})}}}]);