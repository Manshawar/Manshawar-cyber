"use strict";(self.webpackChunkrspress_blog=self.webpackChunkrspress_blog||[]).push([["2790"],{34241:function(e,t,r){r.r(t),r.d(t,{default:()=>y});var i=r(31549),o=r(82190);r(44194);let s=o.ZP.div`
  width: 100%;
  height: 500px;
  display: flex;
  justify-content: center;
  align-items: center;
  perspective: 1000px;
`,a=o.ZP.div`
  width: 600px;
  height: 400px;
  position: relative;
  transform-style: preserve-3d;
  transform: rotateY(-30deg);
`,n=o.ZP.div`
  position: absolute;
  width: 100%;
  height: 100%;
  transform-style: preserve-3d;
`,l=o.ZP.div`
  position: absolute;
  left: -40px;
  height: 100%;
  display: flex;
  flex-direction: column-reverse;
  justify-content: space-between;
`,d=o.ZP.div`
  position: absolute;
  bottom: -30px;
  width: 100%;
  display: flex;
  justify-content: space-around;
`,h=o.ZP.div`
  color: #666;
  font-size: 12px;
`,p=o.ZP.div`
  position: absolute;
  width: 100%;
  height: 100%;
  transform-style: preserve-3d;
`,c=o.ZP.div`
  position: absolute;
  width: 100%;
  height: 100%;
  background: linear-gradient(rgba(0, 0, 0, 0.1) 1px, transparent 1px),
    linear-gradient(90deg, rgba(0, 0, 0, 0.1) 1px, transparent 1px);
  background-size: 20% 20%;
`,x=o.ZP.div`
  position: absolute;
  width: 100%;
  height: 100%;
  transform: rotateY(90deg) translateZ(-1px);
  background: linear-gradient(rgba(0, 0, 0, 0.1) 1px, transparent 1px);
  background-size: 20% 20%;
`,g=o.ZP.div`
  position: absolute;
  width: 100%;
  height: 100%;
  transform: rotateX(90deg) translateZ(0);
  background: linear-gradient(90deg, rgba(0, 0, 0, 0.1) 1px, transparent 1px);
  background-size: 20% 20%;
`,f=o.ZP.div`
  position: absolute;
  width: 100%;
  height: 100%;
  transform-style: preserve-3d;
`,u=o.ZP.div`
  position: absolute;
  bottom: 0;
  width: 40px;
  transform-style: preserve-3d;
  transform: translateX(-20px);
  left: ${e=>25+20*e.index}%;
  z-index: ${e=>e.isMax?10:1};
`,b=o.ZP.div`
  position: relative;
  width: 100%;
  height: ${e=>e.height}px;
  transform-style: preserve-3d;
  transform-origin: bottom center;
  transition: all 0.3s ease;
`,v=o.ZP.div`
  position: absolute;
  width: 100%;
  height: 100%;
  opacity: 0.8;
`,m=(0,o.ZP)(v)`
  background: ${e=>e.color};
  transform: translateZ(20px);
`,Z=(0,o.ZP)(v)`
  background: ${e=>e.color};
  transform: translateZ(-20px);
`,j=(0,o.ZP)(v)`
  width: 40px;
  background: ${e=>e.color};
  filter: brightness(0.8);
  transform: rotateY(90deg) translateZ(-20px);
`,P=(0,o.ZP)(v)`
  width: 40px;
  background: ${e=>e.color};
  filter: brightness(0.8);
  transform: rotateY(-90deg) translateZ(20px);
`,w=(0,o.ZP)(v)`
  height: 40px;
  background: ${e=>e.color};
  filter: brightness(1.2);
  transform: rotateX(-90deg) translateZ(-20px);
`,k=o.ZP.div`
  position: absolute;
  top: -24px;
  width: 100%;
  text-align: center;
  color: ${e=>e.isHighlighted?"#ff6b6b":"#333"};
  font-size: 12px;
  font-weight: ${e=>e.isHighlighted?"bold":"normal"};
  transform: translateZ(20px);
`,y=()=>{let e=[{value:320,color:"#4facfe"},{value:240,color:"#43e97b"},{value:380,color:"#fa709a"},{value:220,color:"#66a6ff"}],t=Math.max(...e.map(e=>e.value)),r=e.findIndex(e=>e.value===t);return(0,i.jsx)(s,{children:(0,i.jsxs)(a,{children:[(0,i.jsxs)(n,{children:[(0,i.jsx)(l,{children:["400","300","200","100","0"].map((e,t)=>(0,i.jsx)(h,{children:e},t))}),(0,i.jsx)(d,{children:["Q1","Q2","Q3","Q4"].map((e,t)=>(0,i.jsx)(h,{children:e},t))}),(0,i.jsxs)(p,{children:[(0,i.jsx)(c,{}),(0,i.jsx)(x,{}),(0,i.jsx)(g,{})]})]}),(0,i.jsx)(f,{children:e.map((e,t)=>(0,i.jsx)(u,{index:t,isMax:t===r,children:(0,i.jsxs)(b,{height:e.value,color:e.color,isHighlighted:t===r,children:[(0,i.jsx)(m,{color:e.color}),(0,i.jsx)(Z,{color:e.color}),(0,i.jsx)(j,{color:e.color}),(0,i.jsx)(P,{color:e.color}),(0,i.jsx)(w,{color:e.color}),(0,i.jsx)(k,{isHighlighted:t===r,children:e.value})]})},t))})]})})}}}]);