"use strict";(self.webpackChunkrspress_blog=self.webpackChunkrspress_blog||[]).push([["1336"],{16623:function(r,t,a){a.r(t),a.d(t,{default:()=>n});var e=a(31549);a(44194);var s=a(82190);let n=()=>{let r=r=>{let{i:t}=r;return(0,s.F4)`0% {
    transform: translate(${30*(t-1)}px, 0);
  }

  30% {
    transform: translate(10px, ${10*t}px) rotate(60deg) scale(${.009*t});
  }

  60% {
    transform: translate(${10*t}px, 10px) rotate(120deg) scale(${.009*t});
  }

  80% {
    transform: translate(0,${30*(t-1)}px) scale(${.009*t});
  }

  100% {
    transform: translate(${30*(t-1)}px, 0);
  }`},t=s.ZP.div`width: 60px;
  height: 60px;
  border-radius: 12px;
  position: absolute;
 
  ${t=>(0,s.iv)`
    &:nth-child(${t.i}) {
      background-color: hsl(${40+3*t.i}, 55%, 50%);
      transform: translate(${30*(t.i-1)}px, 0);

      animation: ${r(t)} 4s infinite;
      animation-delay: ${.02*t.i}s;
    }
  `}
  `;return(0,e.jsx)("div",{className:"mt-10 h-[400px] scale-[20%]  hover:scale-100",children:Array.from({length:4}).map((r,a)=>(0,e.jsx)("div",{style:{transform:`rotate(${90*a}deg)`},children:Array.from({length:40},(r,a)=>(0,e.jsx)(t,{i:a+1},a))},a))})}}}]);