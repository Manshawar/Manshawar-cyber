(self.webpackChunkrspress_blog=self.webpackChunkrspress_blog||[]).push([["3029"],{52720:function(e,n,r){var t={"./simpleWorker.js":"5258","./simpleWorker":"5258"};function o(e){return Promise.resolve().then(function(){if(!r.o(t,e)){var n=Error("Cannot find module '"+e+"'");throw n.code="MODULE_NOT_FOUND",n}return r(t[e])})}o.keys=()=>Object.keys(t),o.id=52720,e.exports=o},99811:function(e,n,r){var t={"./treeViewsDndService.js":["36789"],"./textResourceConfiguration":["54127"],"./unicodeTextModelHighlighter.js":["52746"],"./findSectionHeaders":["56117"],"./languageFeaturesService":["78617"],"./model.js":["68398"],"./editorSimpleWorker":["11879"],"./editorBaseApi":["5035"],"./editorWorker":["74327"],"./editorWorkerHost.js":["89594"],"./semanticTokensDto":["10438"],"./semanticTokensDto.js":["10438"],"./semanticTokensStyling.js":["4951"],"./textResourceConfiguration.js":["54127"],"./editorWorker.js":["74327"],"./languagesAssociations":["6223"],"./markerDecorationsService":["20312"],"./languageFeatureDebounce":["70853"],"./model":["68398"],"./resolverService":["62518"],"./languagesRegistry":["29093"],"./markerDecorations.js":["42250"],"./semanticTokensProviderStyling":["50338"],"./semanticTokensProviderStyling.js":["50338"],"./languageService.js":["2922"],"./semanticTokensStylingService":["13967"],"./getIconClasses.js":["83401"],"./languageFeatures.js":["26211"],"./modelService.js":["88715"],"./languagesRegistry.js":["29093"],"./languageFeatures":["26211"],"./markerDecorationsService.js":["20312"],"./textModelSync/textModelSync.impl.js":["70397"],"./languageService":["2922"],"./editorSimpleWorker.js":["11879"],"./markerDecorations":["42250"],"./treeSitterParserService.js":["16334"],"./findSectionHeaders.js":["56117"],"./treeViewsDnd":["54720"],"./treeViewsDnd.js":["54720"],"./languagesAssociations.js":["6223"],"./textModelSync/textModelSync.protocol":["94564","7123"],"./editorWorkerHost":["89594"],"./textModelSync/textModelSync.impl":["70397"],"./languageFeatureDebounce.js":["70853"],"./treeSitterParserService":["16334"],"./editorBaseApi.js":["5035"],"./textModelSync/textModelSync.protocol.js":["94564","7123"],"./unicodeTextModelHighlighter":["52746"],"./languageFeaturesService.js":["78617"],"./getIconClasses":["83401"],"./semanticTokensStylingService.js":["13967"],"./semanticTokensStyling":["4951"],"./treeViewsDndService":["36789"],"./modelService":["88715"],"./resolverService.js":["62518"]};function o(e){if(!r.o(t,e))return Promise.resolve().then(function(){var n=Error("Cannot find module '"+e+"'");throw n.code="MODULE_NOT_FOUND",n});var n=t[e],o=n[0];return Promise.all(n.slice(1).map(r.e)).then(function(){return r(o)})}o.keys=()=>Object.keys(t),o.id=99811,e.exports=o},6126:function(e){function n(e){var n=Error("Cannot find module '"+e+"'");throw n.code="MODULE_NOT_FOUND",n}n.keys=()=>[],n.resolve=n,n.id=6126,e.exports=n},49270:function(e,n,r){"use strict";r.r(n),r.d(n,{default:()=>a});var t=r(31549),o=r(6603),s=r(91445);function i(e){let n=Object.assign({h1:"h1",a:"a",p:"p",h2:"h2",img:"img",pre:"pre",code:"code"},(0,o.ah)(),e.components);return(0,t.jsxs)(t.Fragment,{children:[(0,t.jsxs)(n.h1,{id:"事件循环",children:["事件循环",(0,t.jsx)(n.a,{className:"header-anchor","aria-hidden":"true",href:"#事件循环",children:"#"})]}),"\n",(0,t.jsx)(n.p,{children:"感谢阮一峰老师的教程 写的非常精髓 这里仅仅只做一个记录\n我会把我的理解用代码实现\n我们先来看看这个例子"}),"\n",(0,t.jsxs)(n.h2,{id:"promise实现异步代码的同步执行",children:["Promise实现异步代码的同步执行",(0,t.jsx)(n.a,{className:"header-anchor","aria-hidden":"true",href:"#promise实现异步代码的同步执行",children:"#"})]}),"\n",(0,t.jsx)(s.default,{}),"\n",(0,t.jsxs)(n.h1,{id:"概念区域",children:["概念区域",(0,t.jsx)(n.a,{className:"header-anchor","aria-hidden":"true",href:"#概念区域",children:"#"})]}),"\n",(0,t.jsxs)(n.h2,{id:"任务队列",children:["任务队列",(0,t.jsx)(n.a,{className:"header-anchor","aria-hidden":"true",href:"#任务队列",children:"#"})]}),"\n",(0,t.jsx)(n.p,{children:"具体来说，异步执行的运行机制如下。（同步执行也是如此，因为它可以被视为没有异步任务的异步执行。）"}),"\n",(0,t.jsx)(n.p,{children:"（1）所有同步任务都在主线程上执行，形成一个执行栈（execution context stack）。"}),"\n",(0,t.jsx)(n.p,{children:'（2）主线程之外，还存在一个"任务队列"（task queue）。只要异步任务有了运行结果，就在"任务队列"之中放置一个事件。'}),"\n",(0,t.jsx)(n.p,{children:'（3）一旦"执行栈"中的所有同步任务执行完毕，系统就会读取"任务队列"，看看里面有哪些事件。那些对应的异步任务，于是结束等待状态，进入执行栈，开始执行。'}),"\n",(0,t.jsx)(n.p,{children:"（4）主线程不断重复上面的第三步。"}),"\n",(0,t.jsx)("img",{src:"https://www.ruanyifeng.com/blogimg/asset/2014/bg2014100801.jpg"}),"\n",(0,t.jsxs)(n.h2,{id:"事件和回调函数",children:["事件和回调函数",(0,t.jsx)(n.a,{className:"header-anchor","aria-hidden":"true",href:"#事件和回调函数",children:"#"})]}),"\n",(0,t.jsx)(n.p,{children:'"任务队列"是一个事件的队列（也可以理解成消息的队列），IO设备完成一项任务，就在"任务队列"中添加一个事件，表示相关的异步任务可以进入"执行栈"了。主线程读取"任务队列"，就是读取里面有哪些事件。'}),"\n",(0,t.jsx)(n.p,{children:'"任务队列"中的事件，除了IO设备的事件以外，还包括一些用户产生的事件（比如鼠标点击、页面滚动等等）。只要指定过回调函数，这些事件发生时就会进入"任务队列"，等待主线程读取。'}),"\n",(0,t.jsx)(n.p,{children:'所谓"回调函数"（callback），就是那些会被主线程挂起来的代码。异步任务必须指定回调函数，当主线程开始执行异步任务，就是执行对应的回调函数。'}),"\n",(0,t.jsx)(n.p,{children:'"任务队列"是一个先进先出的数据结构，排在前面的事件，优先被主线程读取。主线程的读取过程基本上是自动的，只要执行栈一清空，"任务队列"上第一位的事件就自动进入主线程。但是，由于存在后文提到的"定时器"功能，主线程首先要检查一下执行时间，某些事件只有到了规定的时间，才能返回主线程。'}),"\n",(0,t.jsxs)(n.h2,{id:"event-loop",children:["Event Loop",(0,t.jsx)(n.a,{className:"header-anchor","aria-hidden":"true",href:"#event-loop",children:"#"})]}),"\n",(0,t.jsx)(n.p,{children:'主线程从"任务队列"中读取事件，这个过程是循环不断的，所以整个的这种运行机制又称为Event Loop（事件循环）。'}),"\n",(0,t.jsx)(n.p,{children:"为了更好地理解Event Loop，请看下图（转引自Philip Roberts的演讲《Help, I'm stuck in an event-loop》）。"}),"\n",(0,t.jsx)("img",{src:"https://www.ruanyifeng.com/blogimg/asset/2014/bg2014100802.png"}),"\n",(0,t.jsx)(n.p,{children:'上图中，主线程运行的时候，产生堆（heap）和栈（stack），栈中的代码调用各种外部API，它们在"任务队列"中加入各种事件（click，load，done）。只要栈中的代码执行完毕，主线程就会去读取"任务队列"，依次执行那些事件所对应的回调函数。'}),"\n",(0,t.jsx)(n.p,{children:'执行栈中的代码（同步任务），总是在读取"任务队列"（异步任务）之前执行。请看下面这个例子。'}),"\n",(0,t.jsx)(n.pre,{children:(0,t.jsx)(n.code,{className:"language-js",children:"   var req = new XMLHttpRequest();\n    req.open('GET', url);    \n    req.onload = function (){};    \n    req.onerror = function (){};    \n    req.send();\n"})}),"\n",(0,t.jsx)(n.p,{children:'上面代码中的req.send方法是Ajax操作向服务器发送数据，它是一个异步任务，意味着只有当前脚本的所有代码执行完，系统才会去读取"任务队列"。所以，它与下面的写法等价。'}),"\n",(0,t.jsx)(n.pre,{children:(0,t.jsx)(n.code,{className:"language-js",children:"    var req = new XMLHttpRequest();\n    req.open('GET', url);\n    req.send();g\n    req.onload = function (){};    \n    req.onerror = function (){};   \n"})}),"\n",(0,t.jsx)(n.p,{children:'也就是说，指定回调函数的部分（onload和onerror），在send()方法的前面或后面无关紧要，因为它们属于执行栈的一部分，系统总是执行完它们，才会去读取"任务队列"。'}),"\n",(0,t.jsxs)(n.h2,{id:"定时器",children:["定时器",(0,t.jsx)(n.a,{className:"header-anchor","aria-hidden":"true",href:"#定时器",children:"#"})]}),"\n",(0,t.jsx)(n.p,{children:'除了放置异步任务的事件，"任务队列"还可以放置定时事件，即指定某些代码在多少时间之后执行。这叫做"定时器"（timer）功能，也就是定时执行的代码。'}),"\n",(0,t.jsx)(n.p,{children:"定时器功能主要由setTimeout()和setInterval()这两个函数来完成，它们的内部运行机制完全一样，区别在于前者指定的代码是一次性执行，后者则为反复执行。以下主要讨论setTimeout()。"}),"\n",(0,t.jsx)(n.p,{children:"setTimeout()接受两个参数，第一个是回调函数，第二个是推迟执行的毫秒数。"}),"\n",(0,t.jsx)(n.pre,{children:(0,t.jsx)(n.code,{className:"language-js",children:"console.log(1);\nsetTimeout(function(){console.log(2);},1000);\nconsole.log(3);\n"})}),"\n",(0,t.jsx)(n.p,{children:"上面代码的执行结果是1，3，2，因为setTimeout()将第二行推迟到1000毫秒之后执行。"}),"\n",(0,t.jsx)(n.p,{children:"如果将setTimeout()的第二个参数设为0，就表示当前代码执行完（执行栈清空）以后，立即执行（0毫秒间隔）指定的回调函数。"}),"\n",(0,t.jsx)(n.pre,{children:(0,t.jsx)(n.code,{className:"language-js",children:"setTimeout(function(){console.log(1);}, 0);\nconsole.log(2);\n"})}),"\n",(0,t.jsx)(n.p,{children:'上面代码的执行结果总是2，1，因为只有在执行完第二行以后，系统才会去执行"任务队列"中的回调函数。'}),"\n",(0,t.jsx)(n.p,{children:'总之，setTimeout(fn,0)的含义是，指定某个任务在主线程最早可得的空闲时间执行，也就是说，尽可能早得执行。它在"任务队列"的尾部添加一个事件，因此要等到同步任务和"任务队列"现有的事件都处理完，才会得到执行。'}),"\n",(0,t.jsx)(n.p,{children:"HTML5标准规定了setTimeout()的第二个参数的最小值（最短间隔），不得低于4毫秒，如果低于这个值，就会自动增加。在此之前，老版本的浏览器都将最短间隔设为10毫秒。另外，对于那些DOM的变动（尤其是涉及页面重新渲染的部分），通常不会立即执行，而是每16毫秒执行一次。这时使用requestAnimationFrame()的效果要好于setTimeout()。"}),"\n",(0,t.jsx)(n.p,{children:'需要注意的是，setTimeout()只是将事件插入了"任务队列"，必须等到当前代码（执行栈）执行完，主线程才会去执行它指定的回调函数。要是当前代码耗时很长，有可能要等很久，所以并没有办法保证，回调函数一定会在setTimeout()指定的时间执行。'})]})}function l(){let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},{wrapper:n}=Object.assign({},(0,o.ah)(),e.components);return n?(0,t.jsx)(n,{...e,children:(0,t.jsx)(i,{...e})}):i(e)}let a=l;l.__RSPRESS_PAGE_META={},l.__RSPRESS_PAGE_META["guide%2F%E6%9C%9D%E8%8A%B1%E5%A4%95%E6%8B%BE%2F%E4%BA%8B%E4%BB%B6%E5%BE%AA%E7%8E%AF.mdx"]={toc:[{text:"Promise实现异步代码的同步执行",id:"promise实现异步代码的同步执行",depth:2},{text:"任务队列",id:"任务队列",depth:2},{text:"事件和回调函数",id:"事件和回调函数",depth:2},{text:"Event Loop",id:"event-loop",depth:2},{text:"定时器",id:"定时器",depth:2}],title:"概念区域",headingTitle:"概念区域",frontmatter:{}}},91445:function(e,n,r){"use strict";r.r(n),r.d(n,{default:()=>a});var t=r(31549),o=r(44194),s=r(80673),i=r(86974);function l(e){let{value:n="",language:r="javascript",theme:i="vs-dark",height:l="500px",width:a="100%",onChange:c,onRun:d,...u}=e,[h,m]=(0,o.useState)([]),g=(0,o.useRef)(null),x=(0,o.useCallback)(e=>function(){for(var n=arguments.length,r=Array(n),t=0;t<n;t++)r[t]=arguments[t];let o=r.map(e=>"object"==typeof e?JSON.stringify(e,null,2):String(e)).join(" ");m(n=>[...n,{type:e,content:o,timestamp:Date.now()}]);let s=window.originalConsole;s&&s[e]&&s[e](...r)},[]),p=async e=>new Promise((n,r)=>{try{let t=`
          let timeoutIds = [];
          let intervalIds = [];
          
          // 重写定时器函数以跟踪ID
          const originalSetTimeout = window.setTimeout;
          const originalSetInterval = window.setInterval;
          
          window.setTimeout = (...args) => {
            const id = originalSetTimeout(...args);
            timeoutIds.push(id);
         
            const index = timeoutIds.indexOf(id);
            const originalCallback = args[0];
            args[0] = (...cbArgs) => {
              timeoutIds.splice(index, 1);
              return originalCallback(...cbArgs);
            };
            return id;
          };
          
          window.setInterval = (...args) => {
            const id = originalSetInterval(...args);
            intervalIds.push(id);
            return id;
          };

          try {
            ${e}
          } catch (error) {
            console.error(error instanceof Error ? error.message : String(error));
          }

          // 返回一个 Promise，等待所有计时器完成
          return new Promise(resolve => {
            const checkTimeouts = () => {
           
              // 保存当前的定时器数量，避免在检查过程中创建新的定时器
              const currentTimeouts = [...timeoutIds];
              if (timeoutIds.length > 0) {
                // 检查是否所有当前定时器都已完成
                const allCompleted = currentTimeouts.every(id => !timeoutIds.includes(id));
                if (allCompleted) {
                  // 清理所有interval
                  intervalIds.forEach(id => clearInterval(id));
                  // 恢复原始的定时器函数
                  window.setTimeout = originalSetTimeout;
                  window.setInterval = originalSetInterval;
                  resolve();
                } else {
                  originalSetTimeout(checkTimeouts, 100);
                }
              } else {
                // 清理所有interval
                intervalIds.forEach(id => clearInterval(id));
                // 恢复原始的定时器函数
                window.setTimeout = originalSetTimeout;
                window.setInterval = originalSetInterval;
                resolve();
              }
            };
            checkTimeouts();
          });
        `;new(Object.getPrototypeOf(async function(){})).constructor(t)().then(n).catch(r)}catch(e){r(e)}}),j=async()=>{if(!g.current)return;let e=g.current.getValue();m([]);let n={log:console.log,error:console.error,warn:console.warn,info:console.info};window.originalConsole=n,console.log=x("log"),console.error=x("error"),console.warn=x("warn"),console.info=x("info");try{await p(e),d&&d(e)}catch(e){console.error(e instanceof Error?e.message:String(e))}finally{Object.assign(console,n)}};return(0,t.jsxs)("div",{className:"flex w-full h-full min-h-[500px] bg-[#1e1e1e] text-white rounded-lg overflow-hidden border border-[#333]",children:[(0,t.jsxs)("div",{className:"flex-1 flex flex-col",children:[(0,t.jsx)("div",{className:"flex justify-end items-center px-3 py-2 bg-[#252526] border-b border-[#333]",children:(0,t.jsx)("button",{onClick:j,className:"px-3 py-1 text-white text-sm rounded transition-colors bg-[#0098ff] hover:bg-[#0082db]",children:"运行"})}),(0,t.jsx)("div",{className:"flex-1",children:(0,t.jsx)(s.ML,{height:"100%",defaultValue:n,defaultLanguage:r,theme:i,onChange:c,onMount:e=>{g.current=e},options:{minimap:{enabled:!1},fontSize:14,lineNumbers:"on",scrollBeyondLastLine:!1,roundedSelection:!1,padding:{top:10},automaticLayout:!0,tabSize:2,wordWrap:"on"},...u})})]}),(0,t.jsxs)("div",{className:"w-[40%] border-l border-[#333] flex flex-col",children:[(0,t.jsxs)("div",{className:"flex justify-between items-center px-3 py-2 bg-[#252526] border-b border-[#333]",children:[(0,t.jsx)("span",{className:"text-sm text-[#ccc]",children:"控制台"}),(0,t.jsx)("button",{onClick:()=>{m([])},className:"px-3 py-1 bg-[#333] text-white text-sm rounded hover:bg-[#444] transition-colors",children:"清除"})]}),(0,t.jsx)("div",{className:"flex-1 overflow-auto p-2 font-mono text-sm",children:h.map((e,n)=>(0,t.jsx)("div",{className:`py-1 border-b border-[#333] whitespace-pre-wrap ${"error"===e.type?"text-[#ff5555]":"warn"===e.type?"text-[#ffb86c]":"info"===e.type?"text-[#8be9fd]":"text-[#f8f8f2]"}`,children:e.content},e.timestamp+"-"+n))})]})]})}function a(){return(0,o.useRef)(null),(0,t.jsx)("div",{children:(0,t.jsx)(l,{value:` function eventLoop(){
    new Promise((resolve,reject)=>{
      setTimeout(()=>{
      console.log("1")
      },1000)
      resolve("")
    }).then(()=>{
      console.log("2")
    })
    console.log("end")
   
  }
     eventLoop()
  `})})}s._m.config({monaco:i})}}]);