"use strict";(self.webpackChunkrspress_blog=self.webpackChunkrspress_blog||[]).push([["8759"],{66188:function(e,t,i){i.r(t),i.d(t,{default:()=>r});var s=i(31549),n=i(82190);let r=()=>{let e=n.ZP.div`height:400px;`,t=n.ZP.div`
        width: 80%;
        height: 300px;
        display: flex;
        gap:1em;
        justify-content: space-between;
        align-items: flex-end;
        background-color: #f0f0f0;
        padding: 10px;
        position: relative;`,i=n.ZP.div`
        width: 30px;
        background-color: #3498db;
        transition: height 0.5s ease-in-out;
        position: relative;
  `;return(0,s.jsx)(e,{children:(0,s.jsx)(t,{children:Array.from({length:7}).map((e,t)=>(0,s.jsx)(i,{style:{height:100*Math.random()+"%"}},t))})})}}}]);