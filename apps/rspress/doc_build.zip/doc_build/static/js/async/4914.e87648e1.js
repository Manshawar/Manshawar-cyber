"use strict";(self.webpackChunkrspress_blog=self.webpackChunkrspress_blog||[]).push([["4914"],{84362:function(e,r,t){t.r(r),t.d(r,{default:()=>l});var i=t(31549),s=t(82190);let l=()=>{let e=s.ZP.div`height:400px;`,r=s.ZP.div`
     border-bottom: 1px solid;
        border-left: 1px solid;
        height: ${200}px;
        width: ${200}px;

        margin: 1em;
        padding: 0;
        position: relative;
  `;s.ZP.ul`
 list-style: none;
        margin: 0;
        padding: 0;
  `;let t=s.ZP.li`
  background-color: rgb(14, 41, 163);
        border: 2px solid rgb(14, 41, 163);
         list-style: none;
        border-radius: 50%;
        width: 10px;
        height: 10px;
        bottom:${e=>e.y}px;
        left:${e=>e.x}px;
        position: absolute;
        transform: translateX(-5px);
  `;return(0,i.jsx)(e,{children:(0,i.jsx)(r,{children:[[40,20],[80,40],[120,80],[160,40],[200,20]].map((e,r)=>(0,i.jsx)(t,{x:e[0],y:e[1]},r))})})}}}]);