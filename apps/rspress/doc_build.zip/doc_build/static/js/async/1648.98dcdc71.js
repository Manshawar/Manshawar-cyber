"use strict";(self.webpackChunkrspress_blog=self.webpackChunkrspress_blog||[]).push([["1648"],{6152:function(e,t,r){r.r(t),r.d(t,{default:()=>o});var s=r(31549),i=r(82190);let n=["#222","#401a2a","#741a38","#9b123c","#c10a40"].reverse(),o=()=>{let e=i.ZP.div`overflow: hidden;height:400px; perspective: 1000px; position: relative;transform-style: preserve-3d;`,t=i.ZP.div` transform-style: preserve-3d; transform:translateZ(-200px) rotateX(-35deg) rotateY(-45deg) `,r=i.ZP.div`
  width: ${e=>e.rect+1}px;
  height: ${e=>e.rect}px;
  background:${e=>e.color};
  position: relative;
  transform-style: preserve-3d; 
  
 &:before,
&:after {
  width: inherit;
  height: inherit;
  content:"";
    background:${e=>e.color};
    width: ${e=>e.rect}px;
  height: ${e=>e.rect}px;
    position: absolute;
    left:0;
    top:0; 
    filter: brightness(1.3);
    border:none
}
&:after{
 
   transform: rotateX(-90deg);
    transform-origin: center top;
}
&:before{
  
  transform: rotateY(-90deg);
    transform-origin: right center;

}
  `,o=i.ZP.div`transform-style: preserve-3d;`,a=(0,i.F4)`from{
transform:translate(0em) scale3d(1, 1, 1);
  }
  to{
transform:translate(7em) scale3d(0, 0, 0);
  }
  `,l=(0,i.F4)`
    to {
    transform: rotateY(1turn); // 在最后一帧的时候将做360旋转
  }
  `,f=(0,i.ZP)(o)`
  animation: ${l} ${8}s steps(4) infinite;
  `,c=(0,i.ZP)(o)`
 animation: ${a} ${2}s ease-in-out infinite;;
  `,d=(0,i.ZP)(f)`
   animation-direction: reverse;
   animation-timing-function: steps(4, start);
  `;return(0,s.jsxs)(e,{children:[(0,s.jsx)(t,{className:"flex flex-col justify-start w-full h-full items-center gap-10 absolute top-0 left-0",children:n.map((e,t)=>(0,s.jsx)(r,{color:e,index:t,rect:30}))}),(0,s.jsx)(t,{className:"flex flex-col justify-start w-full h-full items-center gap-10 absolute top-0 left-0",children:n.map((e,t)=>(0,s.jsx)(d,{children:(0,s.jsx)(c,{children:(0,s.jsx)(f,{children:(0,s.jsx)(r,{color:e,index:t,rect:30})})})}))})]})}}}]);