"use strict";(self.webpackChunkrspress_blog=self.webpackChunkrspress_blog||[]).push([["5343"],{66502:function(e,t,r){r.r(t),r.d(t,{default:()=>c});var i=r(31549),s=r(6603),a=r(66188),n=r(90203),o=r(84362),d=r(34241);function l(e){let t=Object.assign({h1:"h1",a:"a",p:"p",code:"code"},(0,s.ah)(),e.components);return(0,i.jsxs)(i.Fragment,{children:[(0,i.jsxs)(t.h1,{id:"css图表",children:["css图表",(0,i.jsx)(t.a,{className:"header-anchor","aria-hidden":"true",href:"#css图表",children:"#"})]}),"\n",(0,i.jsx)(t.p,{children:"CSS 实现柱状图"}),"\n",(0,i.jsx)(a.default,{}),"\n",(0,i.jsxs)(t.h1,{id:"css饼图",children:["css饼图",(0,i.jsx)(t.a,{className:"header-anchor","aria-hidden":"true",href:"#css饼图",children:"#"})]}),"\n",(0,i.jsx)(n.default,{}),"\n",(0,i.jsxs)(t.h1,{id:"pointchart",children:["pointChart",(0,i.jsx)(t.a,{className:"header-anchor","aria-hidden":"true",href:"#pointchart",children:"#"})]}),"\n",(0,i.jsx)(o.default,{}),"\n",(0,i.jsxs)(t.h1,{id:"折线图",children:["折线图",(0,i.jsx)(t.a,{className:"header-anchor","aria-hidden":"true",href:"#折线图",children:"#"})]}),"\n",(0,i.jsx)(t.p,{children:"点与点的连接，实际上是斜边，我们使用三角函数进行处理"}),"\n",(0,i.jsx)(t.p,{children:(0,i.jsx)(t.code,{children:"sin（x）= 对边 / 斜边"})}),"\n",(0,i.jsx)(t.p,{children:(0,i.jsx)(t.code,{children:"var angle = Math.acos(对边 / 斜边) * (180 / Math.PI);"})}),"\n",(0,i.jsxs)(t.h1,{id:"3d柱状图",children:["3d柱状图",(0,i.jsx)(t.a,{className:"header-anchor","aria-hidden":"true",href:"#3d柱状图",children:"#"})]}),"\n",(0,i.jsx)(d.default,{})]})}function h(){let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},{wrapper:t}=Object.assign({},(0,s.ah)(),e.components);return t?(0,i.jsx)(t,{...e,children:(0,i.jsx)(l,{...e})}):l(e)}let c=h;h.__RSPRESS_PAGE_META={},h.__RSPRESS_PAGE_META["guide%2Fvr%2Fchart.mdx"]={toc:[],title:"3d柱状图",headingTitle:"3d柱状图",frontmatter:{}}},66188:function(e,t,r){r.r(t),r.d(t,{default:()=>a});var i=r(31549),s=r(82190);let a=()=>{let e=s.ZP.div`height:400px;`,t=s.ZP.div`
        width: 80%;
        height: 300px;
        display: flex;
        gap:1em;
        justify-content: space-between;
        align-items: flex-end;
        background-color: #f0f0f0;
        padding: 10px;
        position: relative;`,r=s.ZP.div`
        width: 30px;
        background-color: #3498db;
        transition: height 0.5s ease-in-out;
        position: relative;
  `;return(0,i.jsx)(e,{children:(0,i.jsx)(t,{children:Array.from({length:7}).map((e,t)=>(0,i.jsx)(r,{style:{height:100*Math.random()+"%"}},t))})})}},84362:function(e,t,r){r.r(t),r.d(t,{default:()=>a});var i=r(31549),s=r(82190);let a=()=>{let e=s.ZP.div`height:400px;`,t=s.ZP.div`
     border-bottom: 1px solid;
        border-left: 1px solid;
        height: ${200}px;
        width: ${200}px;

        margin: 1em;
        padding: 0;
        position: relative;
  `;s.ZP.ul`
 list-style: none;
        margin: 0;
        padding: 0;
  `;let r=s.ZP.li`
  background-color: rgb(14, 41, 163);
        border: 2px solid rgb(14, 41, 163);
         list-style: none;
        border-radius: 50%;
        width: 10px;
        height: 10px;
        bottom:${e=>e.y}px;
        left:${e=>e.x}px;
        position: absolute;
        transform: translateX(-5px);
  `;return(0,i.jsx)(e,{children:(0,i.jsx)(t,{children:[[40,20],[80,40],[120,80],[160,40],[200,20]].map((e,t)=>(0,i.jsx)(r,{x:e[0],y:e[1]},t))})})}},90203:function(e,t,r){r.r(t),r.d(t,{default:()=>d});var i=r(31549),s=r(82190),a=r(44194),n=r(62377),o=r(80438);let d=()=>{let e=(0,n.e7)(),t=s.ZP.div`height:500px`,r=s.ZP.div`height:150px;position:relative`,d=s.ZP.div`
  height:150px;
  position:absolute;
  left:50%;
  transform:translateX(-50%);
  width:150px;
  border-radius:100%;
  box-shadow:0px 0px 8px rgba(0,0,0,0.5);
  z-index:1;
  `,l=s.ZP.div`
        position: absolute;
        width: 150px;
        height: 150px;
        border-radius: 100%;

  `,h=(0,s.ZP)(l)`
  transition: all 1s;
  clip: rect(0px, 75px, 150px, 0px);
 transform: rotate(30deg);
  `,c=(0,s.ZP)(l)`
  clip: rect(0px, 150px, 150px, 75px);

  `,x=s.ZP.div` position: absolute;
    width: 120px;
    height: 120px;
     background-color:${e?"#191d24":"#fff"};
    border-radius: 100%;
    top: 15px;
    left: 15px;
    box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.5) inset;
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index:2;

    `,p=s.ZP.div`
     width: 300px;
        height: 300px;
  background: conic-gradient(#179067, #62e317, #d7f10f, #ffc403, #fcc202, #ff7327, #ff7327, #FF5800, #ff5900, #f64302, #ff0000, #ff0000);
     border-radius: 50%;
        position: relative;
           
  `,f=s.ZP.div`
     position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        z-index: 2;
        width: 260px;
        height: 260px;
        background-color:${e?"#191d24":"#fff"};
        border-radius: 50%;
  `,g=(0,a.useRef)(null),[u,b]=(0,a.useState)({len:0,percent:0});return(0,a.useEffect)(()=>{if(g.current)b({len:2*g.current.r.baseVal.value*Math.PI,percent:Math.round(100*Math.random())/100})},[]),(0,i.jsxs)(t,{className:"flex flex-col justify-between items-center",children:[(0,i.jsx)(r,{children:(0,i.jsxs)(d,{children:[(0,i.jsx)(x,{}),(0,i.jsx)(c,{style:{transform:"rotate(0deg)"},children:(0,i.jsx)(h,{style:{backgroundColor:"#3498db",transform:"rotate(120deg)"}})}),(0,i.jsx)(c,{style:{transform:"rotate(120deg)"},children:(0,i.jsx)(h,{style:{backgroundColor:"#2ecc71",transform:"rotate(120deg)"}})}),(0,i.jsx)(c,{style:{transform:"rotate(240deg)"},children:(0,i.jsx)(h,{style:{backgroundColor:"#e74c3c",transform:"rotate(120deg)"}})})]})}),(0,i.jsx)(o.Z,{min:0,max:1,style:{width:"200px"},defaultValue:u.percent,onChangeComplete:e=>b({...u,percent:e}),step:.01}),(0,i.jsxs)(p,{children:[(0,i.jsx)("svg",{style:{transform:"rotate(-90deg)"},width:"300",height:"300",children:(0,i.jsx)("circle",{r:"140",ref:g,cx:"150",cy:"150",className:"stroke-[#f2f2f2] ","stroke-width":"21",fill:"transparent",style:{strokeDashoffset:-u.len*u.percent,strokeDasharray:880}})}),(0,i.jsx)(f,{})]})]})}},34241:function(e,t,r){r.r(t),r.d(t,{default:()=>k});var i=r(31549),s=r(82190);r(44194);let a=s.ZP.div`
  width: 100%;
  height: 500px;
  display: flex;
  justify-content: center;
  align-items: center;
  perspective: 1000px;
`,n=s.ZP.div`
  width: 600px;
  height: 400px;
  position: relative;
  transform-style: preserve-3d;
  transform: rotateY(-30deg);
`,o=s.ZP.div`
  position: absolute;
  width: 100%;
  height: 100%;
  transform-style: preserve-3d;
`,d=s.ZP.div`
  position: absolute;
  left: -40px;
  height: 100%;
  display: flex;
  flex-direction: column-reverse;
  justify-content: space-between;
`,l=s.ZP.div`
  position: absolute;
  bottom: -30px;
  width: 100%;
  display: flex;
  justify-content: space-around;
`,h=s.ZP.div`
  color: #666;
  font-size: 12px;
`,c=s.ZP.div`
  position: absolute;
  width: 100%;
  height: 100%;
  transform-style: preserve-3d;
`,x=s.ZP.div`
  position: absolute;
  width: 100%;
  height: 100%;
  background: linear-gradient(rgba(0, 0, 0, 0.1) 1px, transparent 1px),
    linear-gradient(90deg, rgba(0, 0, 0, 0.1) 1px, transparent 1px);
  background-size: 20% 20%;
`,p=s.ZP.div`
  position: absolute;
  width: 100%;
  height: 100%;
  transform: rotateY(90deg) translateZ(-1px);
  background: linear-gradient(rgba(0, 0, 0, 0.1) 1px, transparent 1px);
  background-size: 20% 20%;
`,f=s.ZP.div`
  position: absolute;
  width: 100%;
  height: 100%;
  transform: rotateX(90deg) translateZ(0);
  background: linear-gradient(90deg, rgba(0, 0, 0, 0.1) 1px, transparent 1px);
  background-size: 20% 20%;
`,g=s.ZP.div`
  position: absolute;
  width: 100%;
  height: 100%;
  transform-style: preserve-3d;
`,u=s.ZP.div`
  position: absolute;
  bottom: 0;
  width: 40px;
  transform-style: preserve-3d;
  transform: translateX(-20px);
  left: ${e=>25+20*e.index}%;
  z-index: ${e=>e.isMax?10:1};
`,b=s.ZP.div`
  position: relative;
  width: 100%;
  height: ${e=>e.height}px;
  transform-style: preserve-3d;
  transform-origin: bottom center;
  transition: all 0.3s ease;
`,j=s.ZP.div`
  position: absolute;
  width: 100%;
  height: 100%;
  opacity: 0.8;
`,m=(0,s.ZP)(j)`
  background: ${e=>e.color};
  transform: translateZ(20px);
`,v=(0,s.ZP)(j)`
  background: ${e=>e.color};
  transform: translateZ(-20px);
`,Z=(0,s.ZP)(j)`
  width: 40px;
  background: ${e=>e.color};
  filter: brightness(0.8);
  transform: rotateY(90deg) translateZ(-20px);
`,P=(0,s.ZP)(j)`
  width: 40px;
  background: ${e=>e.color};
  filter: brightness(0.8);
  transform: rotateY(-90deg) translateZ(20px);
`,w=(0,s.ZP)(j)`
  height: 40px;
  background: ${e=>e.color};
  filter: brightness(1.2);
  transform: rotateX(-90deg) translateZ(-20px);
`,y=s.ZP.div`
  position: absolute;
  top: -24px;
  width: 100%;
  text-align: center;
  color: ${e=>e.isHighlighted?"#ff6b6b":"#333"};
  font-size: 12px;
  font-weight: ${e=>e.isHighlighted?"bold":"normal"};
  transform: translateZ(20px);
`,k=()=>{let e=[{value:320,color:"#4facfe"},{value:240,color:"#43e97b"},{value:380,color:"#fa709a"},{value:220,color:"#66a6ff"}],t=Math.max(...e.map(e=>e.value)),r=e.findIndex(e=>e.value===t);return(0,i.jsx)(a,{children:(0,i.jsxs)(n,{children:[(0,i.jsxs)(o,{children:[(0,i.jsx)(d,{children:["400","300","200","100","0"].map((e,t)=>(0,i.jsx)(h,{children:e},t))}),(0,i.jsx)(l,{children:["Q1","Q2","Q3","Q4"].map((e,t)=>(0,i.jsx)(h,{children:e},t))}),(0,i.jsxs)(c,{children:[(0,i.jsx)(x,{}),(0,i.jsx)(p,{}),(0,i.jsx)(f,{})]})]}),(0,i.jsx)(g,{children:e.map((e,t)=>(0,i.jsx)(u,{index:t,isMax:t===r,children:(0,i.jsxs)(b,{height:e.value,color:e.color,isHighlighted:t===r,children:[(0,i.jsx)(m,{color:e.color}),(0,i.jsx)(v,{color:e.color}),(0,i.jsx)(Z,{color:e.color}),(0,i.jsx)(P,{color:e.color}),(0,i.jsx)(w,{color:e.color}),(0,i.jsx)(y,{isHighlighted:t===r,children:e.value})]})},t))})]})})}}}]);