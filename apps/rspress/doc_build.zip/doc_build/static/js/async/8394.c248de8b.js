(self.webpackChunkrspress_blog=self.webpackChunkrspress_blog||[]).push([["8394"],{52720:function(e,r,t){var o={"./simpleWorker.js":"5258","./simpleWorker":"5258"};function n(e){return Promise.resolve().then(function(){if(!t.o(o,e)){var r=Error("Cannot find module '"+e+"'");throw r.code="MODULE_NOT_FOUND",r}return t(o[e])})}n.keys=()=>Object.keys(o),n.id=52720,e.exports=n},99811:function(e,r,t){var o={"./treeViewsDndService.js":["36789"],"./textResourceConfiguration":["54127"],"./unicodeTextModelHighlighter.js":["52746"],"./findSectionHeaders":["56117"],"./languageFeaturesService":["78617"],"./model.js":["68398"],"./editorSimpleWorker":["11879"],"./editorBaseApi":["5035"],"./editorWorker":["74327"],"./editorWorkerHost.js":["89594"],"./semanticTokensDto":["10438"],"./semanticTokensDto.js":["10438"],"./semanticTokensStyling.js":["4951"],"./textResourceConfiguration.js":["54127"],"./editorWorker.js":["74327"],"./languagesAssociations":["6223"],"./markerDecorationsService":["20312"],"./languageFeatureDebounce":["70853"],"./model":["68398"],"./resolverService":["62518"],"./languagesRegistry":["29093"],"./markerDecorations.js":["42250"],"./semanticTokensProviderStyling":["50338"],"./semanticTokensProviderStyling.js":["50338"],"./languageService.js":["2922"],"./semanticTokensStylingService":["13967"],"./getIconClasses.js":["83401"],"./languageFeatures.js":["26211"],"./modelService.js":["88715"],"./languagesRegistry.js":["29093"],"./languageFeatures":["26211"],"./markerDecorationsService.js":["20312"],"./textModelSync/textModelSync.impl.js":["70397"],"./languageService":["2922"],"./editorSimpleWorker.js":["11879"],"./markerDecorations":["42250"],"./treeSitterParserService.js":["16334"],"./findSectionHeaders.js":["56117"],"./treeViewsDnd":["54720"],"./treeViewsDnd.js":["54720"],"./languagesAssociations.js":["6223"],"./textModelSync/textModelSync.protocol":["94564","7123"],"./editorWorkerHost":["89594"],"./textModelSync/textModelSync.impl":["70397"],"./languageFeatureDebounce.js":["70853"],"./treeSitterParserService":["16334"],"./editorBaseApi.js":["5035"],"./textModelSync/textModelSync.protocol.js":["94564","7123"],"./unicodeTextModelHighlighter":["52746"],"./languageFeaturesService.js":["78617"],"./getIconClasses":["83401"],"./semanticTokensStylingService.js":["13967"],"./semanticTokensStyling":["4951"],"./treeViewsDndService":["36789"],"./modelService":["88715"],"./resolverService.js":["62518"]};function n(e){if(!t.o(o,e))return Promise.resolve().then(function(){var r=Error("Cannot find module '"+e+"'");throw r.code="MODULE_NOT_FOUND",r});var r=o[e],n=r[0];return Promise.all(r.slice(1).map(t.e)).then(function(){return t(n)})}n.keys=()=>Object.keys(o),n.id=99811,e.exports=n},6126:function(e){function r(e){var r=Error("Cannot find module '"+e+"'");throw r.code="MODULE_NOT_FOUND",r}r.keys=()=>[],r.resolve=r,r.id=6126,e.exports=r},91445:function(e,r,t){"use strict";t.r(r),t.d(r,{default:()=>a});var o=t(31549),n=t(44194),s=t(80673),i=t(86974);function l(e){let{value:r="",language:t="javascript",theme:i="vs-dark",height:l="500px",width:a="100%",onChange:c,onRun:d,...u}=e,[g,m]=(0,n.useState)([]),f=(0,n.useRef)(null),v=(0,n.useCallback)(e=>function(){for(var r=arguments.length,t=Array(r),o=0;o<r;o++)t[o]=arguments[o];let n=t.map(e=>"object"==typeof e?JSON.stringify(e,null,2):String(e)).join(" ");m(r=>[...r,{type:e,content:n,timestamp:Date.now()}]);let s=window.originalConsole;s&&s[e]&&s[e](...t)},[]),x=async e=>new Promise((r,t)=>{try{let o=`
          let timeoutIds = [];
          let intervalIds = [];
          
          // 重写定时器函数以跟踪ID
          const originalSetTimeout = window.setTimeout;
          const originalSetInterval = window.setInterval;
          
          window.setTimeout = (...args) => {
            const id = originalSetTimeout(...args);
            timeoutIds.push(id);
         
            const index = timeoutIds.indexOf(id);
            const originalCallback = args[0];
            args[0] = (...cbArgs) => {
              timeoutIds.splice(index, 1);
              return originalCallback(...cbArgs);
            };
            return id;
          };
          
          window.setInterval = (...args) => {
            const id = originalSetInterval(...args);
            intervalIds.push(id);
            return id;
          };

          try {
            ${e}
          } catch (error) {
            console.error(error instanceof Error ? error.message : String(error));
          }

          // 返回一个 Promise，等待所有计时器完成
          return new Promise(resolve => {
            const checkTimeouts = () => {
           
              // 保存当前的定时器数量，避免在检查过程中创建新的定时器
              const currentTimeouts = [...timeoutIds];
              if (timeoutIds.length > 0) {
                // 检查是否所有当前定时器都已完成
                const allCompleted = currentTimeouts.every(id => !timeoutIds.includes(id));
                if (allCompleted) {
                  // 清理所有interval
                  intervalIds.forEach(id => clearInterval(id));
                  // 恢复原始的定时器函数
                  window.setTimeout = originalSetTimeout;
                  window.setInterval = originalSetInterval;
                  resolve();
                } else {
                  originalSetTimeout(checkTimeouts, 100);
                }
              } else {
                // 清理所有interval
                intervalIds.forEach(id => clearInterval(id));
                // 恢复原始的定时器函数
                window.setTimeout = originalSetTimeout;
                window.setInterval = originalSetInterval;
                resolve();
              }
            };
            checkTimeouts();
          });
        `;new(Object.getPrototypeOf(async function(){})).constructor(o)().then(r).catch(t)}catch(e){t(e)}}),p=async()=>{if(!f.current)return;let e=f.current.getValue();m([]);let r={log:console.log,error:console.error,warn:console.warn,info:console.info};window.originalConsole=r,console.log=v("log"),console.error=v("error"),console.warn=v("warn"),console.info=v("info");try{await x(e),d&&d(e)}catch(e){console.error(e instanceof Error?e.message:String(e))}finally{Object.assign(console,r)}};return(0,o.jsxs)("div",{className:"flex w-full h-full min-h-[500px] bg-[#1e1e1e] text-white rounded-lg overflow-hidden border border-[#333]",children:[(0,o.jsxs)("div",{className:"flex-1 flex flex-col",children:[(0,o.jsx)("div",{className:"flex justify-end items-center px-3 py-2 bg-[#252526] border-b border-[#333]",children:(0,o.jsx)("button",{onClick:p,className:"px-3 py-1 text-white text-sm rounded transition-colors bg-[#0098ff] hover:bg-[#0082db]",children:"运行"})}),(0,o.jsx)("div",{className:"flex-1",children:(0,o.jsx)(s.ML,{height:"100%",defaultValue:r,defaultLanguage:t,theme:i,onChange:c,onMount:e=>{f.current=e},options:{minimap:{enabled:!1},fontSize:14,lineNumbers:"on",scrollBeyondLastLine:!1,roundedSelection:!1,padding:{top:10},automaticLayout:!0,tabSize:2,wordWrap:"on"},...u})})]}),(0,o.jsxs)("div",{className:"w-[40%] border-l border-[#333] flex flex-col",children:[(0,o.jsxs)("div",{className:"flex justify-between items-center px-3 py-2 bg-[#252526] border-b border-[#333]",children:[(0,o.jsx)("span",{className:"text-sm text-[#ccc]",children:"控制台"}),(0,o.jsx)("button",{onClick:()=>{m([])},className:"px-3 py-1 bg-[#333] text-white text-sm rounded hover:bg-[#444] transition-colors",children:"清除"})]}),(0,o.jsx)("div",{className:"flex-1 overflow-auto p-2 font-mono text-sm",children:g.map((e,r)=>(0,o.jsx)("div",{className:`py-1 border-b border-[#333] whitespace-pre-wrap ${"error"===e.type?"text-[#ff5555]":"warn"===e.type?"text-[#ffb86c]":"info"===e.type?"text-[#8be9fd]":"text-[#f8f8f2]"}`,children:e.content},e.timestamp+"-"+r))})]})]})}function a(){return(0,n.useRef)(null),(0,o.jsx)("div",{children:(0,o.jsx)(l,{value:` function eventLoop(){
    new Promise((resolve,reject)=>{
      setTimeout(()=>{
      console.log("1")
      },1000)
      resolve("")
    }).then(()=>{
      console.log("2")
    })
    console.log("end")
   
  }
     eventLoop()
  `})})}s._m.config({monaco:i})}}]);