"use strict";(self.webpackChunkrspress_blog=self.webpackChunkrspress_blog||[]).push([["2138"],{64758:function(e,n,r){r.r(n),r.d(n,{default:()=>m});var t=r(31549),a=r(6603),i=r(89071),s=r(16623),l=r(6152),o=r(60113);function d(e){let n=Object.assign({h1:"h1",a:"a",h2:"h2",p:"p",img:"img",pre:"pre",code:"code"},(0,a.ah)(),e.components);return(0,t.jsxs)(t.Fragment,{children:[(0,t.jsxs)(n.h1,{id:"css的高级技巧",children:["css的高级技巧",(0,t.jsx)(n.a,{className:"header-anchor","aria-hidden":"true",href:"#css的高级技巧",children:"#"})]}),"\n",(0,t.jsxs)(n.h2,{id:"transform-字体模糊问题",children:["Transform 字体模糊问题",(0,t.jsx)(n.a,{className:"header-anchor","aria-hidden":"true",href:"#transform-字体模糊问题",children:"#"})]}),"\n",(0,t.jsx)(n.p,{children:"transform2D 我们一般用于 2D 场景的变换，transform3D 用于 3D 场景的变换，但是在一些特殊场景 transform2D 会字体模糊问题，比如使用transform: translate(-50%, -50%)。"}),"\n",(0,t.jsx)(n.p,{children:"导致字体模糊的原因是：这个变换会触发浏览器对元素进行硬件加速。在某些浏览器中，硬件加速可能会导致更简化的文本渲染方法，从而出现字体模糊的情况。"}),"\n",(0,t.jsx)(n.p,{children:"解决这个问题的方法之一是使用 transform: translate3d(-50%, -50%, 0)，将元素的变换转换为 3D 变换。这样可以强制浏览器使用更高质量的文本渲染，从而避免字体模糊的问题。"}),"\n",(0,t.jsx)(n.p,{children:"另外，还可以尝试使用 backface-visibility: hidden 属性，将元素的背面隐藏起来，这有助于提高字体的清晰度。"}),"\n",(0,t.jsxs)(n.h2,{id:"matrix3d",children:["matrix3d",(0,t.jsx)(n.a,{className:"header-anchor","aria-hidden":"true",href:"#matrix3d",children:"#"})]}),"\n",(0,t.jsx)(n.p,{children:"可以发现，matrix3d() API 中，有16个参数，但是他的参数的顺序和我们上面给出的顺序并不相同，上面给出的是数学中的矩阵的正常格式："}),"\n",(0,t.jsx)(n.p,{children:"行（row）是横向的，列（column）是纵先的。但是Web当中矩阵是刚好相反，即列是横向的，行是纵向的。类似下面这样："}),"\n",(0,t.jsx)("img",{src:"https://i-blog.csdnimg.cn/blog_migrate/81f887f9443d7a238c906238650545d9.png#pic_center",alt:"在这里插入图片描述",referrerPolicy:"no-referrer"}),"\n",(0,t.jsx)(n.p,{children:"所以大家应该注意，前文所有的推导结果，放到matrix3d中，顺序应该是下面这样：\nmatrix3d(a00,a10,a20,a30,a01,a11,a21,a31,a02,a12,a22,a32,a03,a13,a23,a33)。"}),"\n",(0,t.jsx)("img",{src:"https://i-blog.csdnimg.cn/blog_migrate/f0ac87c4896267ff2fa0e004bd62b15b.png#pic_centernpm install antd --save",alt:"在这里插入图片描述",referrerPolicy:"no-referrer"}),"\n",(0,t.jsx)("a",{href:"https://blog.csdn.net/qq_35543489/article/details/113694496",target:"_blank",children:"矩阵详解"}),"\n",(0,t.jsx)(i.default,{}),"\n",(0,t.jsxs)(n.h2,{id:"animation-动画",children:["Animation 动画",(0,t.jsx)(n.a,{className:"header-anchor","aria-hidden":"true",href:"#animation-动画",children:"#"})]}),"\n",(0,t.jsx)(s.default,{}),"\n",(0,t.jsx)(n.pre,{children:(0,t.jsx)(n.code,{className:"language-tsx",children:'import styles, { keyframes, css } from "styled-components";\nexport default () => {\n  let a1 = (props: { i: number }) => {\n    let { i } = props;\n    return keyframes`0% {\n    transform: translate(${30 * (i - 1)}px, 0);\n  }\n\n  30% {\n    transform: translate(10px, ${10 * i}px) rotate(60deg) scale(${i * 0.009});\n  }\n\n  60% {\n    transform: translate(${10 * i}px, 10px) rotate(120deg) scale(${i * 0.009});\n  }\n\n  80% {\n    transform: translate(0,${30 * (i - 1)}px) scale(${i * 0.009});\n  }\n\n  100% {\n    transform: translate(${30 * (i - 1)}px, 0);\n  }`;\n  };\n\n  // animation: ${a1} 4s infinite;\n  let BoxItem = styles.div<{ i: number; intI: number }>`width: 60px;\n  height: 60px;\n  border-radius: 12px;\n  position: absolute;\n \n  ${props => css`\n    &:nth-child(${props.i}) {\n      background-color: hsl(${40 + 3 * props.i}, 55%, 50%);\n      transform: translate(${30 * (props.i - 1)}px, 0);\n\n      animation: ${a1(props)} 4s infinite;\n      animation-delay: ${props.i * 0.02}s;\n    }\n  `}\n  `;\n  return (\n    <div className="mt-10 h-[400px] scale-[20%]  hover:scale-100">\n      {Array.from({ length: 4 }).map((_, intI) => {\n        return (\n          <div key={intI} style={{ transform: `rotate(${intI * 90}deg)` }}>\n            {Array.from({ length: 40 }, (_, index) => (\n              <BoxItem key={index} i={index + 1} intI={intI + 1}></BoxItem>\n            ))}\n          </div>\n        );\n      })}\n    </div>\n  );\n};\n\n'})}),"\n",(0,t.jsxs)(n.h2,{id:"3d动画",children:["3d动画",(0,t.jsx)(n.a,{className:"header-anchor","aria-hidden":"true",href:"#3d动画",children:"#"})]}),"\n",(0,t.jsx)(l.default,{}),"\n",(0,t.jsx)(n.p,{children:"我画了一个简单的流程图讲述其核心概念"}),"\n",(0,t.jsx)("img",{src:"https://ik.imagekit.io/Manshawar/ferris_8PiNzixa3"}),"\n",(0,t.jsx)(n.p,{children:"这里是代码:"}),"\n",(0,t.jsx)(n.pre,{children:(0,t.jsx)(n.code,{className:"language-tsx",children:'\nimport styles, { keyframes, css } from "styled-components";\nlet colorList = ["#222", "#401a2a", "#741a38", "#9b123c", "#c10a40"].reverse();\nexport default () => {\n  let Container = styles.div`overflow: hidden;height:700px; perspective: 1000px; position: relative;transform-style: preserve-3d;`;\n  let Assembly = styles.div` transform-style: preserve-3d; transform:rotateX(-35deg) rotateY(-45deg);padding-top: 20px;`;\n  let Cube = styles.div<{ color: string; index: number; rect: number }>`\n  width: ${props => props.rect}px;\n  height: ${props => props.rect}px;\n  background:${props => props.color};\n  position: relative;\n  transform-style: preserve-3d; \n &:before,\n&:after {\n  width: inherit;\n  height: inherit;\n  content:"";\n    background:${props => props.color};\n    width: ${props => props.rect}px;\n  height: ${props => props.rect}px;\n    position: absolute;\n    left:0;\n    top:0; \n    display:block;\n    filter: brightness(1.15);\n}\n&:after{\ntransform:rotateX(-90deg);\ntransform-origin: center top;\n}\n&:before{\ntransform:rotateY(-90deg);\ntransform-origin: center right\n\n}\n  `;\n  let t = 2;\n  let T3d = styles.div`transform-style: preserve-3d;`;\n  let move = keyframes`from{\ntransform:translate(0em) scale3d(1, 1, 1);\n  }\n  to{\ntransform:translate(7em) scale3d(0, 0, 0);\n  }\n  `;\n  let switchAnimation = keyframes`\n    to {\n    transform: rotateY(1turn); // 在最后一帧的时候将做360旋转\n  }\n  `;\n  let Switch_in = styles(T3d)`\n  animation: ${switchAnimation} ${4 * t}s steps(4) infinite;\n  `;\n  let Move = styles(T3d)`\n animation: ${move} ${t}s ease-in-out infinite;;\n  `;\n  let Move_out = styles(Switch_in)`\n   animation-direction: reverse;\n   animation-timing-function: steps(4, start);\n  `;\n  return (\n    <Container>\n      <Assembly className="flex flex-col justify-start w-full h-full items-center gap-10 absolute top-0 left-0">\n        {colorList.map((item, index) => {\n          return <Cube color={item} index={index} rect={30}></Cube>;\n        })}\n      </Assembly>\n      <Assembly className="flex flex-col justify-start w-full h-full items-center gap-10 absolute top-0 left-0">\n        {colorList.map((item, index) => {\n          return (\n            <Move_out>\n              <Move>\n                <Switch_in>\n                  <Cube color={item} index={index} rect={30}></Cube>\n                </Switch_in>\n              </Move>\n            </Move_out>\n          );\n        })}\n      </Assembly>\n    </Container>\n  );\n};\n\n'})}),"\n",(0,t.jsxs)(n.h2,{id:"渐变",children:["渐变",(0,t.jsx)(n.a,{className:"header-anchor","aria-hidden":"true",href:"#渐变",children:"#"})]}),"\n",(0,t.jsx)(o.default,{}),"\n",(0,t.jsxs)(n.h2,{id:"伪类-is-和-where的逻辑函数和条件函数",children:["伪类 :is 和 :where的逻辑函数和条件函数",(0,t.jsx)(n.a,{className:"header-anchor","aria-hidden":"true",href:"#伪类-is-和-where的逻辑函数和条件函数",children:"#"})]}),"\n",(0,t.jsx)(n.p,{children:":is() 和 :where() 是 CSS 中的伪类选择器，它们允许我们以一种高效的方式对一系列选择器进行分组和定位。"}),"\n",(0,t.jsx)(n.p,{children:"我们看下下面代码演示，仔细体会简化代码："}),"\n",(0,t.jsx)(n.pre,{children:(0,t.jsx)(n.code,{className:"language-css",children:"button.foces, button:focus {  } \n->\nbutton:is(.focus, :focus) {}\n\ncontent > h1, content > h2, content > h3, content > h4 {}\n->\ncontent > :is(h1, h2, h3, h4)\n\n"})}),"\n",(0,t.jsx)(n.p,{children:"两者唯一区别在于权重，:where 的权重为 0，:is 作为伪类选择器的权重为 10。"})]})}function c(){let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},{wrapper:n}=Object.assign({},(0,a.ah)(),e.components);return n?(0,t.jsx)(n,{...e,children:(0,t.jsx)(d,{...e})}):d(e)}let m=c;c.__RSPRESS_PAGE_META={},c.__RSPRESS_PAGE_META["guide%2Fvr%2Fcss.mdx"]={toc:[{text:"Transform 字体模糊问题",id:"transform-字体模糊问题",depth:2},{text:"matrix3d",id:"matrix3d",depth:2},{text:"Animation 动画",id:"animation-动画",depth:2},{text:"3d动画",id:"3d动画",depth:2},{text:"渐变",id:"渐变",depth:2},{text:"伪类 :is 和 :where的逻辑函数和条件函数",id:"伪类-is-和-where的逻辑函数和条件函数",depth:2}],title:"css的高级技巧",headingTitle:"css的高级技巧",frontmatter:{}}},6152:function(e,n,r){r.r(n),r.d(n,{default:()=>s});var t=r(31549),a=r(82190);let i=["#222","#401a2a","#741a38","#9b123c","#c10a40"].reverse(),s=()=>{let e=a.ZP.div`overflow: hidden;height:400px; perspective: 1000px; position: relative;transform-style: preserve-3d;`,n=a.ZP.div` transform-style: preserve-3d; transform:translateZ(-200px) rotateX(-35deg) rotateY(-45deg) `,r=a.ZP.div`
  width: ${e=>e.rect+1}px;
  height: ${e=>e.rect}px;
  background:${e=>e.color};
  position: relative;
  transform-style: preserve-3d; 
  
 &:before,
&:after {
  width: inherit;
  height: inherit;
  content:"";
    background:${e=>e.color};
    width: ${e=>e.rect}px;
  height: ${e=>e.rect}px;
    position: absolute;
    left:0;
    top:0; 
    filter: brightness(1.3);
    border:none
}
&:after{
 
   transform: rotateX(-90deg);
    transform-origin: center top;
}
&:before{
  
  transform: rotateY(-90deg);
    transform-origin: right center;

}
  `,s=a.ZP.div`transform-style: preserve-3d;`,l=(0,a.F4)`from{
transform:translate(0em) scale3d(1, 1, 1);
  }
  to{
transform:translate(7em) scale3d(0, 0, 0);
  }
  `,o=(0,a.F4)`
    to {
    transform: rotateY(1turn); // 在最后一帧的时候将做360旋转
  }
  `,d=(0,a.ZP)(s)`
  animation: ${o} ${8}s steps(4) infinite;
  `,c=(0,a.ZP)(s)`
 animation: ${l} ${2}s ease-in-out infinite;;
  `,m=(0,a.ZP)(d)`
   animation-direction: reverse;
   animation-timing-function: steps(4, start);
  `;return(0,t.jsxs)(e,{children:[(0,t.jsx)(n,{className:"flex flex-col justify-start w-full h-full items-center gap-10 absolute top-0 left-0",children:i.map((e,n)=>(0,t.jsx)(r,{color:e,index:n,rect:30}))}),(0,t.jsx)(n,{className:"flex flex-col justify-start w-full h-full items-center gap-10 absolute top-0 left-0",children:i.map((e,n)=>(0,t.jsx)(m,{children:(0,t.jsx)(c,{children:(0,t.jsx)(d,{children:(0,t.jsx)(r,{color:e,index:n,rect:30})})})}))})]})}},60113:function(e,n,r){r.r(n),r.d(n,{default:()=>i});var t=r(31549),a=r(82190);["#222","#401a2a","#741a38","#9b123c","#c10a40"].reverse();let i=()=>{let e=a.ZP.div`overflow: hidden;height:400px;`,n=a.ZP.div`display:flex;justify-content:center;align-items:center;padding:10px;text-align:center`,r=(0,a.F4)`    0% {
        background-position: -100%;
    }

    100% {
        background-position: 100%;
    }`,i=a.ZP.div`
   width: 300px;
    height: 20px;
    background-image: linear-gradient(45deg, rgba(0, 0, 0, .1) 25%, transparent 25%, transparent 50%, rgba(0, 0, 0, .1) 50%, rgba(0, 0, 0, .1) 75%, transparent 75%, transparent);
    background-size: 1.25em 1.25em;
    animation-name: ${r};
    animation-duration: 6s;
    animation-iteration-count: infinite;
    animation-timing-function: linear;
    background-color: rgb(28, 219, 28);
    border-radius: 10px;
  `;return(0,t.jsx)(e,{children:(0,t.jsxs)("div",{className:"flex justify-between  w-full h-full flex-wrap",children:[(0,t.jsx)(n,{className:"w-[33%] mb-1",style:{background:"linear-gradient(black,white)"},children:"linear-gradient(black,white)"}),(0,t.jsx)(n,{className:"w-[33%] bg-slate-500 mb-1",style:{background:"linear-gradient(to right, black, white)"},children:"linear-gradient(to right, black, white)"}),(0,t.jsx)(n,{className:"w-[33%] bg-slate-500 mb-1",style:{background:"linear-gradient(to right, rgba(200, 40, 10, 1), rgba(230, 40, 10, 0)),linear-gradient(to left, hsl(220, 80%, 45%, 1), hsl(220, 80%, 45%, 0)),linear-gradient(0.5turn, rgba(20, 230, 30, 1), rgba(20, 230, 20, 0))",backgroundBlendMode:"difference"},children:(0,t.jsxs)("div",{children:[(0,t.jsx)("p",{children:"background:"}),(0,t.jsx)("p",{children:"linear-gradient(to right, rgba(200, 40, 10, 1), rgba(230, 40, 10, 0)),"}),(0,t.jsx)("p",{children:"linear-gradient(to left, hsl(220, 80%, 45%, 1), hsl(220, 80%, 45%, 0)),"}),(0,t.jsx)("p",{children:"linear-gradient(0.5turn, rgba(20, 230, 30, 1), rgba(20, 230, 20, 0)),"}),(0,t.jsx)("p",{children:'backgroundBlendMode: "difference",'})]})}),(0,t.jsx)(n,{className:"w-[33%] bg-slate-500 mb-1",style:{background:"repeating-linear-gradient(135deg,  hsl(333, 62%, 47%) 0 10px,   hsl(161, 100%, 64%) 10px 20px)"},children:'background: "repeating-linear-gradient(135deg, hsl(333, 62%, 47%) 0 10px, hsl(161, 100%, 64%) 10px 20px)",'}),(0,t.jsx)(n,{className:"w-[33%] bg-slate-500 mb-1",children:(0,t.jsx)(i,{})}),(0,t.jsx)(n,{className:"w-[33%] bg-slate-500 mb-1",style:{background:"conic-gradient(rgb(28, 150, 215) 0deg 90deg, white 90deg 180deg, rgb(151, 209, 243) 180deg 270deg, white 270deg 360deg)",backgroundSize:"10% 10%"}})]})})}},16623:function(e,n,r){r.r(n),r.d(n,{default:()=>i});var t=r(31549);r(44194);var a=r(82190);let i=()=>{let e=e=>{let{i:n}=e;return(0,a.F4)`0% {
    transform: translate(${30*(n-1)}px, 0);
  }

  30% {
    transform: translate(10px, ${10*n}px) rotate(60deg) scale(${.009*n});
  }

  60% {
    transform: translate(${10*n}px, 10px) rotate(120deg) scale(${.009*n});
  }

  80% {
    transform: translate(0,${30*(n-1)}px) scale(${.009*n});
  }

  100% {
    transform: translate(${30*(n-1)}px, 0);
  }`},n=a.ZP.div`width: 60px;
  height: 60px;
  border-radius: 12px;
  position: absolute;
 
  ${n=>(0,a.iv)`
    &:nth-child(${n.i}) {
      background-color: hsl(${40+3*n.i}, 55%, 50%);
      transform: translate(${30*(n.i-1)}px, 0);

      animation: ${e(n)} 4s infinite;
      animation-delay: ${.02*n.i}s;
    }
  `}
  `;return(0,t.jsx)("div",{className:"mt-10 h-[400px] scale-[20%]  hover:scale-100",children:Array.from({length:4}).map((e,r)=>(0,t.jsx)("div",{style:{transform:`rotate(${90*r}deg)`},children:Array.from({length:40},(e,r)=>(0,t.jsx)(n,{i:r+1},r))},r))})}},89071:function(e,n,r){r.r(n),r.d(n,{default:()=>d});var t=r(31549),a=r(82190),i=r(44194),s=r(20438),l=r(94671),o=r(80438);let d=()=>{let[e,n]=(0,i.useState)([[{val:1,min:0,max:2},{val:0,min:-1,max:1},{val:0,min:-1,max:1},{val:0,min:-2,max:2}],[{val:0,min:-1,max:1},{val:1,min:0,max:2},{val:0,min:-1,max:1},{val:0,min:-2,max:2}],[{val:0,min:0,max:2},{val:0,min:-1,max:1},{val:1,min:0,max:2},{val:0,min:-2,max:2}],[{val:0,min:-10,max:10},{val:0,min:-10,max:10},{val:0,min:-1,max:1},{val:1,min:0,max:2}]]),r=a.ZP.div` width: 100px;
    height: 100px;
    background-color: gray;
    transform: matrix3d(${e.flat().map(e=>e.val).join(",")});`,[d,c]=(0,i.useState)(!1),m=(r,t,a)=>{e[t][a].val=r,n([...e])};return(0,t.jsxs)("div",{className:"mt-10",children:[(0,t.jsx)("div",{children:e.map((e,n)=>(0,t.jsx)("div",{className:"flex gap-3",children:e.map((e,n)=>(0,t.jsx)("div",{children:e.val},n))},n))}),(0,t.jsx)(s.ZP,{theme:{components:{Slider:{railBg:"rgba(2,57,62,.5)"},InputNumber:{controlWidth:48,inputFontSizeLG:8,inputFontSizeSM:6}},token:{colorText:"rgba(30,128,255,.7)"}},children:e.map((e,n)=>(0,t.jsx)("div",{className:"flex justify-evenly gap-3 mt-3",children:e.map((e,r)=>(0,t.jsxs)("div",{className:"w-full flex-col",children:[(0,t.jsxs)("div",{className:"flex justify-between items-center",children:[(0,t.jsxs)("span",{className:"text-[.6rem]",children:[n,",",r]}),(0,t.jsx)(l.Z,{min:e.min,max:e.max,defaultValue:e.val,value:e.val,onChange:e=>m(e,n,r),className:" border-none bg-transparent h-7 "})]}),(0,t.jsx)(o.Z,{className:"flex-1",min:e.min,max:e.max,defaultValue:e.val,onChange:e=>m(e,n,r),step:.01})]},r))},n))}),(0,t.jsx)("div",{className:"flex justify-center w-full h-64 items-center  preserve-3d perspective-500",children:(0,t.jsx)(r,{})})]})}}}]);